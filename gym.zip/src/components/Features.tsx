"use client";

import { motion } from "framer-motion";
import {
  Dumbbell,
  Apple,
  Lock,
  UserCheck,
  Users,
  Snowflake,
  Music,
  Calendar,
} from "lucide-react";
import { cn } from "@/lib/utils";

const features = [
  {
    icon: Dumbbell,
    title: "Premium Equipment",
    description: "State-of-the-art machines and free weights for every workout.",
  },
  {
    icon: Apple,
    title: "Diet Guidance",
    description: "Personalized nutrition plans crafted by expert dietitians.",
  },
  {
    icon: Lock,
    title: "Locker Facility",
    description: "Secure, spacious lockers to keep your belongings safe.",
  },
  {
    icon: UserCheck,
    title: "Personal Coaching",
    description: "One-on-one training with certified fitness professionals.",
  },
  {
    icon: Users,
    title: "Group Classes",
    description: "High-energy classes from yoga to HIIT with expert instructors.",
  },
  {
    icon: Snowflake,
    title: "Air Conditioned",
    description: "Climate-controlled environment for maximum comfort.",
  },
  {
    icon: Music,
    title: "Music Environment",
    description: "Premium sound system to keep your motivation high.",
  },
  {
    icon: Calendar,
    title: "Open Every Day",
    description: "7 days a week access to fit your busy schedule.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" as const },
  },
};

export default function Features() {
  return (
    <section id="features" className="py-24 px-4 sm:px-6 lg:px-8 bg-[#0D0D0D]">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1 mb-4 text-xs font-semibold tracking-widest uppercase text-[#D4AF37] border border-[#D4AF37]/30 rounded-full">
            Why Us
          </span>
          <h2 className="text-4xl sm:text-5xl font-bold text-white tracking-tight">
            Premium Features
          </h2>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                variants={cardVariants}
                whileHover={{ scale: 1.05 }}
                className={cn(
                  "group relative rounded-2xl p-6",
                  "bg-white/5 backdrop-blur-md border border-white/10",
                  "transition-all duration-300",
                  "hover:border-[#D4AF37]/50 hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]"
                )}
              >
                <div className="mb-4 inline-flex items-center justify-center w-14 h-14 rounded-xl bg-[#D4AF37]/10 text-[#D4AF37] transition-all duration-300 group-hover:bg-[#D4AF37]/20 group-hover:shadow-[0_0_20px_rgba(212,175,55,0.3)]">
                  <Icon className="w-7 h-7 transition-transform duration-300 group-hover:scale-110" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-400 leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
