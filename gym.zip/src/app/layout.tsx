import type { Metadata } from "next";
import { Poppins, Inter } from "next/font/google";
import "./globals.css";

const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
});

export const metadata: Metadata = {
  title: "The Empire Best Gym & Fitness Centre | Coimbatore's Premium Fitness Destination",
  description:
    "The Empire Best Gym & Fitness Centre in Coimbatore - Premium fitness destination with world-class equipment, certified trainers, and transformative fitness programs.",
  keywords: [
    "gym coimbatore",
    "fitness centre coimbatore",
    "premium gym",
    "weight training",
    "personal training",
    "body transformation",
    "empire gym",
  ],
  openGraph: {
    title: "The Empire Best Gym & Fitness Centre",
    description: "Coimbatore's Premium Fitness Destination",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${poppins.variable} ${inter.variable}`}>
      <body className="min-h-screen bg-[#0D0D0D] text-white antialiased">
        {children}
      </body>
    </html>
  );
}
