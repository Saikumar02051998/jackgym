import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Programs from "@/components/Programs";
import Features from "@/components/Features";
import Trainers from "@/components/Trainers";
import Transformation from "@/components/Transformation";
import Pricing from "@/components/Pricing";
import Testimonials from "@/components/Testimonials";
import Gallery from "@/components/Gallery";
import BMICalculator from "@/components/BMICalculator";
import GymTimer from "@/components/GymTimer";
import Counter from "@/components/Counter";
import FAQ from "@/components/FAQ";
import Location from "@/components/Location";
import Footer from "@/components/Footer";
import Marquee from "@/components/Marquee";
import MobileBookButton from "@/components/MobileBookButton";
import Particles from "@/components/Particles";
import CursorGlow from "@/components/CursorGlow";

export default function Home() {
  return (
    <div className="relative min-h-screen bg-[#0D0D0D]">
      <Particles />
      <CursorGlow />
      <Navigation />
      <main>
        <Hero />
        <Marquee />
        <About />
        <Programs />
        <Features />
        <Counter />
        <Trainers />
        <Transformation />
        <Pricing />
        <Testimonials />
        <Gallery />
        <BMICalculator />
        <GymTimer />
        <FAQ />
        <Location />
      </main>
      <Footer />
      <MobileBookButton />
    </div>
  );
}
