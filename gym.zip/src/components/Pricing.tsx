"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

const plans = [
  {
    name: "Starter",
    price: "₹999",
    period: "month",
    popular: false,
    features: [
      "Access to gym equipment",
      "Locker facility",
      "Group classes",
      "Basic diet plan",
    ],
  },
  {
    name: "Premium",
    price: "₹7,999",
    period: "year",
    popular: true,
    features: [
      "Everything in Starter",
      "Personal trainer",
      "Advanced diet plan",
      "Priority booking",
      "Steam room access",
    ],
  },
  {
    name: "Elite",
    price: "₹14,999",
    period: "year",
    popular: false,
    features: [
      "Everything in Premium",
      "1-on-1 personal training",
      "Custom workout plan",
      "Nutrition coaching",
      "24/7 trainer support",
      "Free supplements",
    ],
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" as const },
  },
};

export default function Pricing() {
  return (
    <section id="pricing" className="py-24 px-4 sm:px-6 lg:px-8 bg-[#0D0D0D]">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1 mb-4 text-xs font-semibold tracking-widest uppercase text-[#D4AF37] border border-[#D4AF37]/30 rounded-full">
            Membership
          </span>
          <h2 className="text-4xl sm:text-5xl font-bold text-white tracking-tight">
            Choose Your Plan
          </h2>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center max-w-5xl mx-auto"
        >
          {plans.map((plan) => (
            <motion.div
              key={plan.name}
              variants={cardVariants}
              whileHover={{ scale: 1.05 }}
              className={cn(
                "relative rounded-3xl p-8 flex flex-col",
                "bg-white/5 backdrop-blur-md border transition-all duration-300",
                plan.popular
                  ? "border-[#D4AF37] shadow-[0_0_40px_rgba(212,175,55,0.2)] md:scale-110 z-10"
                  : "border-white/10 hover:border-[#D4AF37]/50 hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]"
              )}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-[#D4AF37] text-[#0D0D0D] text-xs font-bold tracking-wider uppercase rounded-full">
                  Most Popular
                </div>
              )}

              <h3 className="text-xl font-semibold text-white mb-2">
                {plan.name}
              </h3>

              <div className="mb-6">
                <span className="text-4xl font-bold text-white">
                  {plan.price}
                </span>
                <span className="text-gray-400 text-sm ml-1">
                  /{plan.period}
                </span>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3 text-gray-300 text-sm">
                    <Check className="w-5 h-5 text-[#D4AF37] shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                className={cn(
                  "w-full py-3 rounded-xl font-semibold text-sm tracking-wide transition-all duration-300",
                  plan.popular
                    ? "bg-gradient-to-r from-[#D4AF37] to-[#B8962E] text-[#0D0D0D] hover:shadow-[0_0_25px_rgba(212,175,55,0.4)]"
                    : "border border-[#D4AF37]/50 text-[#D4AF37] hover:bg-[#D4AF37]/10 hover:border-[#D4AF37]"
                )}
              >
                Join Now
              </button>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
