"use client";

import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import {
  Dumbbell,
  Flame,
  Target,
  UserCheck,
  Zap,
  Heart,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Program {
  title: string;
  description: string;
  icon: LucideIcon;
}

const programs: Program[] = [
  {
    title: "Strength Training",
    description:
      "Build raw power with our state-of-the-art strength training zone",
    icon: Dumbbell,
  },
  {
    title: "Fat Loss",
    description:
      "Shred fat with scientifically designed cardio and circuit routines",
    icon: Flame,
  },
  {
    title: "Bodybuilding",
    description:
      "Sculpt your dream physique with expert bodybuilding programs",
    icon: Target,
  },
  {
    title: "Personal Training",
    description: "One-on-one sessions with certified personal trainers",
    icon: UserCheck,
  },
  {
    title: "HIIT",
    description:
      "High intensity interval training for maximum calorie burn",
    icon: Zap,
  },
  {
    title: "Cardio",
    description:
      "Boost endurance with our premium cardio equipment",
    icon: Heart,
  },
];

function ProgramCard({ program, index }: { program: Program; index: number }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -8;
    const rotateY = ((x - centerX) / centerX) * 8;
    setTilt({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
    setIsHovered(false);
  };

  const Icon = program.icon;

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{
        transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
        transformStyle: "preserve-3d",
      }}
      className="relative group cursor-pointer"
    >
      <div
        className={cn(
          "absolute -inset-[1px] rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500",
          "bg-[length:200%_200%] animate-gradient",
          "bg-gradient-to-r from-[#D4AF37] via-[#E8C84A] to-[#D4AF37]"
        )}
      />

      <div
        className={cn(
          "relative h-full rounded-2xl p-8 transition-all duration-500",
          "bg-[#1A1A1A] border border-[rgba(255,255,255,0.06)]",
          "group-hover:-translate-y-3 group-hover:shadow-[0_20px_60px_-15px_rgba(212,175,55,0.3)]",
          "group-hover:border-transparent"
        )}
      >
        <div
          className={cn(
            "w-16 h-16 rounded-xl flex items-center justify-center mb-6 transition-all duration-500",
            "bg-[rgba(212,175,55,0.1)] border border-[rgba(212,175,55,0.2)]",
            "group-hover:bg-[rgba(212,175,55,0.2)] group-hover:shadow-[0_0_30px_rgba(212,175,55,0.2)]",
            "group-hover:scale-110"
          )}
        >
          <Icon
            className={cn(
              "w-8 h-8 text-[#D4AF37] transition-all duration-500",
              "group-hover:text-[#E8C84A] group-hover:drop-shadow-[0_0_10px_rgba(212,175,55,0.5)]"
            )}
          />
        </div>

        <h3
          className={cn(
            "text-xl font-bold text-white mb-3 transition-colors duration-300",
            "group-hover:text-[#D4AF37]"
          )}
        >
          {program.title}
        </h3>

        <p className="text-[rgba(255,255,255,0.6)] leading-relaxed text-sm">
          {program.description}
        </p>

        <div
          className={cn(
            "absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-[2px] rounded-full transition-all duration-500",
            "bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent",
            "group-hover:w-3/4"
          )}
        />
      </div>
    </motion.div>
  );
}

export default function Programs() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" });

  return (
    <section
      id="programs"
      ref={sectionRef}
      className="relative py-24 md:py-32 bg-[#0D0D0D] overflow-hidden"
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-[#D4AF37] rounded-full mix-blend-multiply filter blur-[150px] opacity-[0.03]" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-[#D4AF37] rounded-full mix-blend-multiply filter blur-[150px] opacity-[0.03]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full text-xs font-semibold tracking-widest uppercase bg-[rgba(212,175,55,0.1)] text-[#D4AF37] border border-[rgba(212,175,55,0.2)] mb-6">
            Our Programs
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white tracking-tight">
            Transform Your{" "}
            <span className="text-[#D4AF37]">Body</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {programs.map((program, index) => (
            <ProgramCard key={program.title} program={program} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
