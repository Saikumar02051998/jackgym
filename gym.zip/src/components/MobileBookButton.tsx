"use client";

import { motion } from "framer-motion";
import { Calendar } from "lucide-react";
import { cn } from "@/lib/utils";

export default function MobileBookButton() {
  return (
    <motion.a
      href="https://wa.me/919876543210?text=I%20want%20to%20book%20a%20free%20trial"
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "fixed bottom-6 left-1/2 z-50 flex items-center gap-2",
        "rounded-full px-6 py-3 text-sm font-semibold text-white",
        "gold-gradient shadow-lg shadow-[#D4AF37]/30",
        "transition-shadow duration-300 hover:shadow-[0_0_30px_rgba(212,175,55,0.5)]",
        "lg:hidden"
      )}
      style={{ transform: "translateX(-50%)" }}
      animate={{ y: [0, -6, 0] }}
      transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
    >
      <Calendar className="h-4 w-4" />
      Book Free Trial
    </motion.a>
  );
}
