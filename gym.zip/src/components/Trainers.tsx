"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

function InstagramIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}

function TwitterIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
    </svg>
  );
}

function LinkedinIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
      <rect width="4" height="12" x="2" y="9" />
      <circle cx="4" cy="4" r="2" />
    </svg>
  );
}
import { cn } from "@/lib/utils";

const trainers = [
  {
    name: "Rajesh Kumar",
    initials: "RK",
    experience: "10+ Years Experience",
    specialization: "Strength & Conditioning Specialist",
    gradient: "from-[#D4AF37] via-[#B8941E] to-[#8B6914]",
    socials: { instagram: "#", twitter: "#", linkedin: "#" },
  },
  {
    name: "Priya Sharma",
    initials: "PS",
    experience: "8+ Years Experience",
    specialization: "Weight Loss & Nutrition Expert",
    gradient: "from-[#D4AF37] via-[#C9A227] to-[#A68B1E]",
    socials: { instagram: "#", twitter: "#", linkedin: "#" },
  },
  {
    name: "Arun Patel",
    initials: "AP",
    experience: "12+ Years Experience",
    specialization: "Bodybuilding Champion",
    gradient: "from-[#D4AF37] via-[#E5C23F] to-[#B8941E]",
    socials: { instagram: "#", twitter: "#", linkedin: "#" },
  },
  {
    name: "Meera Reddy",
    initials: "MR",
    experience: "7+ Years Experience",
    specialization: "Yoga & Functional Training",
    gradient: "from-[#D4AF37] via-[#B8941E] to-[#9A7D16]",
    socials: { instagram: "#", twitter: "#", linkedin: "#" },
  },
];

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0,
    scale: 0.9,
  }),
  center: {
    x: 0,
    opacity: 1,
    scale: 1,
    transition: { duration: 0.5, ease: "easeOut" as const },
  },
  exit: (direction: number) => ({
    x: direction < 0 ? 300 : -300,
    opacity: 0,
    scale: 0.9,
    transition: { duration: 0.5, ease: "easeOut" as const },
  }),
};

export default function Trainers() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const slideNext = useCallback(() => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % trainers.length);
  }, []);

  const slidePrev = useCallback(() => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + trainers.length) % trainers.length);
  }, []);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(slideNext, 4000);
    return () => clearInterval(interval);
  }, [isAutoPlaying, slideNext]);

  const goToSlide = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  return (
    <section id="trainers" className="py-24 px-4 sm:px-6 lg:px-8 bg-[#0D0D0D]">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1 mb-4 text-xs font-semibold tracking-widest uppercase text-[#D4AF37] border border-[#D4AF37]/30 rounded-full">
            Our Team
          </span>
          <h2 className="text-4xl sm:text-5xl font-bold text-white tracking-tight">
            Expert Trainers
          </h2>
        </motion.div>

        <div
          className="relative max-w-4xl mx-auto"
          onMouseEnter={() => setIsAutoPlaying(false)}
          onMouseLeave={() => setIsAutoPlaying(true)}
        >
          <div className="overflow-hidden rounded-3xl">
            <AnimatePresence initial={false} custom={direction}>
              <motion.div
                key={currentIndex}
                custom={direction}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                className="flex justify-center"
              >
                <TrainerCard trainer={trainers[currentIndex]} />
              </motion.div>
            </AnimatePresence>
          </div>

          <button
            onClick={slidePrev}
            className={cn(
              "absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 z-10",
              "w-12 h-12 rounded-full flex items-center justify-center",
              "bg-white/10 backdrop-blur-md border border-white/20",
              "text-white hover:bg-[#D4AF37]/20 hover:border-[#D4AF37]/50",
              "transition-all duration-300 hover:scale-110",
              "hidden sm:flex"
            )}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <button
            onClick={slideNext}
            className={cn(
              "absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 z-10",
              "w-12 h-12 rounded-full flex items-center justify-center",
              "bg-white/10 backdrop-blur-md border border-white/20",
              "text-white hover:bg-[#D4AF37]/20 hover:border-[#D4AF37]/50",
              "transition-all duration-300 hover:scale-110",
              "hidden sm:flex"
            )}
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          <div className="flex justify-center gap-3 mt-8">
            {trainers.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={cn(
                  "w-3 h-3 rounded-full transition-all duration-300",
                  index === currentIndex
                    ? "bg-[#D4AF37] w-8"
                    : "bg-white/20 hover:bg-white/40"
                )}
              />
            ))}
          </div>

          <div className="flex sm:hidden justify-center gap-4 mt-6">
            <button
              onClick={slidePrev}
              className="w-12 h-12 rounded-full flex items-center justify-center bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-[#D4AF37]/20 hover:border-[#D4AF37]/50 transition-all duration-300"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={slideNext}
              className="w-12 h-12 rounded-full flex items-center justify-center bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-[#D4AF37]/20 hover:border-[#D4AF37]/50 transition-all duration-300"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

function TrainerCard({
  trainer,
}: {
  trainer: (typeof trainers)[number];
}) {
  return (
    <div
      className={cn(
        "w-full max-w-lg mx-4 p-8 rounded-3xl",
        "bg-white/5 backdrop-blur-md border border-white/10",
        "transition-all duration-500",
        "hover:border-[#D4AF37]/50 hover:shadow-[0_0_50px_rgba(212,175,55,0.15)]"
      )}
    >
      <div className="flex flex-col items-center text-center">
        <div
          className={cn(
            "relative w-48 h-48 rounded-full mb-6",
            "bg-gradient-to-br",
            trainer.gradient,
            "flex items-center justify-center",
            "shadow-[0_0_40px_rgba(212,175,55,0.3)]",
            "transition-all duration-500",
            "hover:scale-105 hover:shadow-[0_0_60px_rgba(212,175,55,0.5)]"
          )}
        >
          <span className="text-5xl font-bold text-[#0D0D0D] tracking-wider">
            {trainer.initials}
          </span>
          <div className="absolute inset-0 rounded-full border-2 border-[#D4AF37]/30" />
        </div>

        <h3 className="text-2xl font-bold text-white mb-2">{trainer.name}</h3>
        <p className="text-[#D4AF37] font-semibold text-sm mb-1">
          {trainer.experience}
        </p>
        <p className="text-gray-400 text-sm mb-6">{trainer.specialization}</p>

        <div className="flex gap-4">
          <a
            href={trainer.socials.instagram}
            className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center",
              "bg-white/5 border border-white/10",
              "text-gray-400 hover:text-[#D4AF37]",
              "hover:bg-[#D4AF37]/10 hover:border-[#D4AF37]/30",
              "transition-all duration-300 hover:scale-110"
            )}
          >
            <InstagramIcon className="w-4 h-4" />
          </a>
          <a
            href={trainer.socials.twitter}
            className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center",
              "bg-white/5 border border-white/10",
              "text-gray-400 hover:text-[#D4AF37]",
              "hover:bg-[#D4AF37]/10 hover:border-[#D4AF37]/30",
              "transition-all duration-300 hover:scale-110"
            )}
          >
            <TwitterIcon className="w-4 h-4" />
          </a>
          <a
            href={trainer.socials.linkedin}
            className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center",
              "bg-white/5 border border-white/10",
              "text-gray-400 hover:text-[#D4AF37]",
              "hover:bg-[#D4AF37]/10 hover:border-[#D4AF37]/30",
              "transition-all duration-300 hover:scale-110"
            )}
          >
            <LinkedinIcon className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  );
}
