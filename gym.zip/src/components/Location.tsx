"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { MapPin, Phone, Mail, Clock, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

const locationInfo = [
  {
    icon: MapPin,
    label: "Address",
    value: "The Empire Best Gym & Fitness Centre, Hotel AB Merridien, Sastri Road, Ram Nagar, Coimbatore",
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+91 98765 43210",
    href: "tel:+919876543210",
  },
  {
    icon: Mail,
    label: "Email",
    value: "info@theempiregym.com",
    href: "mailto:info@theempiregym.com",
  },
  {
    icon: Clock,
    label: "Working Hours",
    value: "Mon - Sat: 5:00 AM - 11:00 PM | Sun: 7:00 AM - 9:00 PM",
  },
];

export default function Location() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.2 });

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-24 md:py-32 overflow-hidden"
      style={{ backgroundColor: "#0D0D0D" }}
    >
      <div className="container mx-auto px-4 md:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span
            className="inline-block px-4 py-1.5 text-xs font-semibold tracking-widest uppercase rounded-full mb-4"
            style={{
              backgroundColor: "rgba(212, 175, 55, 0.1)",
              color: "#D4AF37",
              border: "1px solid rgba(212, 175, 55, 0.3)",
            }}
          >
            Find Us
          </span>
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight"
            style={{ color: "#FFFFFF" }}
          >
            OUR LOCATION
          </h2>
        </motion.div>

        {/* Split Layout */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left: Google Maps Embed */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="rounded-2xl overflow-hidden"
            style={{
              border: "1px solid rgba(255, 255, 255, 0.1)",
              boxShadow: "0 8px 32px rgba(0, 0, 0, 0.4)",
            }}
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.0!2d76.95!3d11.0!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTHCsDAwJzAwLjAiTiA3NsKwNTcnMDAuMCJF!5e0!3m2!1sen!2sin!4v1234567890"
              width="100%"
              height="400"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Gym Location"
            />
          </motion.div>

          {/* Right: Contact Info Card */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="rounded-2xl p-8 md:p-10"
            style={{
              background: "rgba(255, 255, 255, 0.03)",
              backdropFilter: "blur(20px)",
              border: "1px solid rgba(255, 255, 255, 0.08)",
              boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3)",
            }}
          >
            <h3
              className="text-2xl font-bold mb-8"
              style={{ color: "#FFFFFF" }}
            >
              Get In Touch
            </h3>

            <div className="space-y-6 mb-10">
              {locationInfo.map((item, index) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, x: 30 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <div
                    className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center"
                    style={{
                      backgroundColor: "rgba(212, 175, 55, 0.1)",
                      border: "1px solid rgba(212, 175, 55, 0.2)",
                    }}
                  >
                    <item.icon size={20} style={{ color: "#D4AF37" }} />
                  </div>
                  <div className="flex-1">
                    <p
                      className="text-sm font-semibold mb-1 uppercase tracking-wide"
                      style={{ color: "rgba(255, 255, 255, 0.5)" }}
                    >
                      {item.label}
                    </p>
                    {item.href ? (
                      <a
                        href={item.href}
                        className="text-base transition-colors duration-300 hover:underline"
                        style={{ color: "#FFFFFF" }}
                      >
                        {item.value}
                      </a>
                    ) : (
                      <p className="text-base" style={{ color: "#FFFFFF" }}>
                        {item.value}
                      </p>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <motion.a
                href="https://www.google.com/maps/dir/?api=1&destination=The+Empire+Best+Gym+%26+Fitness+Centre,+Sastri+Road,+Ram+Nagar,+Coimbatore"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className={cn(
                  "flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-semibold text-sm tracking-wide transition-all duration-300"
                )}
                style={{
                  background: "linear-gradient(135deg, #D4AF37 0%, #B8960C 100%)",
                  color: "#0D0D0D",
                  boxShadow: "0 4px 20px rgba(212, 175, 55, 0.3)",
                }}
              >
                <ExternalLink size={16} />
                Get Directions
              </motion.a>

              <motion.a
                href="tel:+919876543210"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className={cn(
                  "flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-semibold text-sm tracking-wide transition-all duration-300"
                )}
                style={{
                  backgroundColor: "transparent",
                  color: "#D4AF37",
                  border: "2px solid #D4AF37",
                }}
              >
                <Phone size={16} />
                Call Now
              </motion.a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
