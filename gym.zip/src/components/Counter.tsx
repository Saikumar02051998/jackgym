"use client";

import { useRef, useEffect, useState } from "react";
import { motion, useInView, animate } from "framer-motion";
import { Users, Award, Dumbbell, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

const counters = [
  { icon: Users, value: 1500, label: "Members", suffix: "+" },
  { icon: Award, value: 12, label: "Certified Trainers", suffix: "+" },
  { icon: Dumbbell, value: 40, label: "Machines", suffix: "+" },
  { icon: Clock, value: 8, label: "Years Experience", suffix: "+" },
];

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [display, setDisplay] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, value, {
      duration: 2,
      ease: "easeOut",
      onUpdate(v) {
        setDisplay(Math.round(v));
      },
    });
    return () => controls.stop();
  }, [inView, value]);

  return (
    <span ref={ref}>
      {display.toLocaleString()}
      {suffix}
    </span>
  );
}

export default function Counter() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: "-100px" });

  return (
    <section
      ref={containerRef}
      className={cn(
        "relative w-full py-24 px-4 sm:px-6 lg:px-8 overflow-hidden",
        "bg-[#0D0D0D]"
      )}
    >
      {/* Background diagonal gold lines */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(135deg, transparent, transparent 40px, #D4AF37 40px, #D4AF37 41px)",
        }}
      />

      <div className="relative z-10 mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block rounded-full border border-[#D4AF37]/30 px-4 py-1 text-xs font-semibold uppercase tracking-widest text-[#D4AF37]">
            Our Numbers
          </span>
          <h2 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
            Proven Results
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {counters.map((counter, i) => {
            const Icon = counter.icon;
            return (
              <motion.div
                key={counter.label}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: i * 0.15, ease: "easeOut" }}
                className={cn(
                  "group relative rounded-2xl p-8 text-center",
                  "bg-white/5 backdrop-blur-md border border-white/10",
                  "transition-all duration-300",
                  "hover:border-[#D4AF37]/50 hover:shadow-[0_0_30px_rgba(212,175,55,0.15)]"
                )}
              >
                <div className="mb-5 inline-flex h-16 w-16 items-center justify-center rounded-xl bg-[#D4AF37]/10 text-[#D4AF37] transition-all duration-300 group-hover:bg-[#D4AF37]/20 group-hover:shadow-[0_0_20px_rgba(212,175,55,0.3)]">
                  <Icon className="h-8 w-8 transition-transform duration-300 group-hover:scale-110" />
                </div>
                <div className="mb-2 bg-gradient-to-r from-[#D4AF37] to-[#F5E7A3] bg-clip-text text-5xl font-bold text-transparent sm:text-6xl">
                  <AnimatedCounter
                    value={counter.value}
                    suffix={counter.suffix}
                  />
                </div>
                <p className="text-sm font-medium uppercase tracking-wider text-gray-400">
                  {counter.label}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
