"use client";

const quotes = [
  "YOUR BODY CAN STAND ALMOST ANYTHING. IT'S YOUR MIND THAT YOU HAVE TO CONVINCE.",
  "THE ONLY BAD WORKOUT IS THE ONE THAT DIDN'T HAPPEN.",
  "STRONG IS THE NEW BEAUTIFUL.",
  "PAIN IS TEMPORARY. QUITTING LASTS FOREVER.",
  "THE EMPIRE STRONGEST SELF",
  "TRAIN INSANE OR REMAIN THE SAME.",
  "NO PAIN NO GAIN",
];

const doubledQuotes = [...quotes, ...quotes];

export default function Marquee() {
  return (
    <div className="relative overflow-hidden border-y border-[#D4AF37]/20 bg-[#0D0D0D] py-6">
      {/* Left fade */}
      <div className="pointer-events-none absolute left-0 top-0 z-10 h-full w-24 bg-gradient-to-r from-[#0D0D0D] to-transparent" />
      {/* Right fade */}
      <div className="pointer-events-none absolute right-0 top-0 z-10 h-full w-24 bg-gradient-to-l from-[#0D0D0D] to-transparent" />

      <div className="animate-marquee flex whitespace-nowrap">
        {doubledQuotes.map((quote, i) => (
          <span
            key={i}
            className="mx-8 text-xl font-bold uppercase tracking-wider text-[#D4AF37]"
          >
            {quote}
            <span className="mx-8 text-[#D4AF37]/40">&#10022;</span>
          </span>
        ))}
      </div>
    </div>
  );
}
