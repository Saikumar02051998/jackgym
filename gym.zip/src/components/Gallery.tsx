"use client";

import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, Maximize2 } from "lucide-react";
import { cn } from "@/lib/utils";

type Category = "All" | "Strength" | "Workout" | "Equipment" | "Members";

interface GalleryItem {
  id: number;
  title: string;
  category: Category;
  gradient: string;
  span: string;
}

const galleryItems: GalleryItem[] = [
  {
    id: 1,
    title: "Strength Zone",
    category: "Strength",
    gradient: "from-[#1A1A1A] via-[#2A2A2A] to-[#D4AF37]",
    span: "md:col-span-2 md:row-span-2",
  },
  {
    id: 2,
    title: "Cardio Arena",
    category: "Workout",
    gradient: "from-[#0D0D0D] via-[#1A1A1A] to-[#C9A227]",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    id: 3,
    title: "Free Weights",
    category: "Strength",
    gradient: "from-[#2A2A2A] via-[#1A1A1A] to-[#B8941E]",
    span: "md:col-span-1 md:row-span-2",
  },
  {
    id: 4,
    title: "Group Session",
    category: "Workout",
    gradient: "from-[#1A1A1A] via-[#D4AF37] to-[#0D0D0D]",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    id: 5,
    title: "Modern Equipment",
    category: "Equipment",
    gradient: "from-[#0D0D0D] via-[#2A2A2A] to-[#E8C84A]",
    span: "md:col-span-2 md:row-span-1",
  },
  {
    id: 6,
    title: "Power Lifters",
    category: "Members",
    gradient: "from-[#2A2A2A] via-[#1A1A1A] to-[#D4AF37]",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    id: 7,
    title: "Cable Station",
    category: "Equipment",
    gradient: "from-[#1A1A1A] via-[#C9A227] to-[#0D0D0D]",
    span: "md:col-span-1 md:row-span-2",
  },
  {
    id: 8,
    title: "HIIT Zone",
    category: "Workout",
    gradient: "from-[#0D0D0D] via-[#1A1A1A] to-[#B8941E]",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    id: 9,
    title: "Elite Athletes",
    category: "Members",
    gradient: "from-[#2A2A2A] via-[#D4AF37] to-[#1A1A1A]",
    span: "md:col-span-2 md:row-span-1",
  },
  {
    id: 10,
    title: "Treadmill Zone",
    category: "Equipment",
    gradient: "from-[#1A1A1A] via-[#2A2A2A] to-[#E8C84A]",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    id: 11,
    title: "Battle Ropes",
    category: "Strength",
    gradient: "from-[#0D0D0D] via-[#C9A227] to-[#1A1A1A]",
    span: "md:col-span-1 md:row-span-1",
  },
  {
    id: 12,
    title: "Fitness Community",
    category: "Members",
    gradient: "from-[#2A2A2A] via-[#1A1A1A] to-[#D4AF37]",
    span: "md:col-span-1 md:row-span-2",
  },
];

const categories: Category[] = ["All", "Strength", "Workout", "Equipment", "Members"];

export default function Gallery() {
  const [activeCategory, setActiveCategory] = useState<Category>("All");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filteredItems =
    activeCategory === "All"
      ? galleryItems
      : galleryItems.filter((item) => item.category === activeCategory);

  const openLightbox = useCallback((index: number) => {
    setLightboxIndex(index);
  }, []);

  const closeLightbox = useCallback(() => {
    setLightboxIndex(null);
  }, []);

  const goNext = useCallback(() => {
    if (lightboxIndex === null) return;
    setLightboxIndex((prev) =>
      prev === null ? null : (prev + 1) % filteredItems.length
    );
  }, [lightboxIndex, filteredItems.length]);

  const goPrev = useCallback(() => {
    if (lightboxIndex === null) return;
    setLightboxIndex((prev) =>
      prev === null
        ? null
        : (prev - 1 + filteredItems.length) % filteredItems.length
    );
  }, [lightboxIndex, filteredItems.length]);

  useEffect(() => {
    if (lightboxIndex === null) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowRight") goNext();
      if (e.key === "ArrowLeft") goPrev();
    };
    document.addEventListener("keydown", handleKeyDown);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [lightboxIndex, closeLightbox, goNext, goPrev]);

  return (
    <section id="gallery" className="py-24 md:py-32 bg-[#0D0D0D] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="inline-block px-4 py-2 rounded-full text-xs font-semibold tracking-widest uppercase bg-[rgba(212,175,55,0.1)] text-[#D4AF37] border border-[rgba(212,175,55,0.2)] mb-6">
            Gallery
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white tracking-tight">
            Our Fitness{" "}
            <span className="text-[#D4AF37]">World</span>
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={cn(
                "px-6 py-2.5 rounded-full text-sm font-medium transition-all duration-300",
                activeCategory === category
                  ? "bg-[#D4AF37] text-[#0D0D0D] shadow-[0_0_20px_rgba(212,175,55,0.3)]"
                  : "bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10 hover:text-white hover:border-white/20"
              )}
            >
              {category}
            </button>
          ))}
        </motion.div>

        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 auto-rows-[200px]"
        >
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                className={cn(
                  "relative group cursor-pointer rounded-2xl overflow-hidden",
                  item.span
                )}
                onClick={() => openLightbox(index)}
              >
                <div
                  className={cn(
                    "absolute inset-0 bg-gradient-to-br",
                    item.gradient,
                    "transition-transform duration-700 ease-out",
                    "group-hover:scale-110"
                  )}
                />

                <div
                  className={cn(
                    "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500",
                    "bg-gradient-to-t from-black/90 via-black/50 to-transparent"
                  )}
                />

                <div
                  className={cn(
                    "absolute inset-0 flex flex-col items-center justify-center",
                    "opacity-0 group-hover:opacity-100 transition-all duration-500",
                    "translate-y-4 group-hover:translate-y-0"
                  )}
                >
                  <Maximize2 className="w-8 h-8 text-[#D4AF37] mb-3 drop-shadow-[0_0_10px_rgba(212,175,55,0.5)]" />
                  <h3 className="text-lg font-bold text-white text-center px-4 mb-1">
                    {item.title}
                  </h3>
                  <span className="text-xs font-medium text-[#D4AF37] uppercase tracking-wider">
                    {item.category}
                  </span>
                </div>

                <div
                  className={cn(
                    "absolute top-4 right-4 w-10 h-10 rounded-full",
                    "bg-black/30 backdrop-blur-md border border-white/20",
                    "flex items-center justify-center",
                    "opacity-0 group-hover:opacity-100 transition-all duration-300",
                    "scale-75 group-hover:scale-100"
                  )}
                >
                  <Maximize2 className="w-4 h-4 text-white" />
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      <AnimatePresence>
        {lightboxIndex !== null && filteredItems[lightboxIndex] && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-sm"
            onClick={closeLightbox}
          >
            <button
              onClick={closeLightbox}
              className={cn(
                "absolute top-6 right-6 z-50",
                "w-12 h-12 rounded-full flex items-center justify-center",
                "bg-white/10 backdrop-blur-md border border-white/20",
                "text-white hover:bg-[#D4AF37]/20 hover:border-[#D4AF37]/50",
                "transition-all duration-300 hover:scale-110"
              )}
            >
              <X className="w-6 h-6" />
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                goPrev();
              }}
              className={cn(
                "absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-50",
                "w-14 h-14 rounded-full flex items-center justify-center",
                "bg-white/10 backdrop-blur-md border border-white/20",
                "text-white hover:bg-[#D4AF37]/20 hover:border-[#D4AF37]/50",
                "transition-all duration-300 hover:scale-110"
              )}
            >
              <ChevronLeft className="w-7 h-7" />
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                goNext();
              }}
              className={cn(
                "absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-50",
                "w-14 h-14 rounded-full flex items-center justify-center",
                "bg-white/10 backdrop-blur-md border border-white/20",
                "text-white hover:bg-[#D4AF37]/20 hover:border-[#D4AF37]/50",
                "transition-all duration-300 hover:scale-110"
              )}
            >
              <ChevronRight className="w-7 h-7" />
            </button>

            <AnimatePresence mode="wait">
              <motion.div
                key={lightboxIndex}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="relative max-w-5xl w-full mx-4 md:mx-8 aspect-video rounded-3xl overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                <div
                  className={cn(
                    "absolute inset-0 bg-gradient-to-br",
                    filteredItems[lightboxIndex].gradient
                  )}
                />

                <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/80 to-transparent">
                  <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">
                    {filteredItems[lightboxIndex].title}
                  </h3>
                  <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-[rgba(212,175,55,0.2)] text-[#D4AF37] border border-[rgba(212,175,55,0.3)]">
                    {filteredItems[lightboxIndex].category}
                  </span>
                </div>
              </motion.div>
            </AnimatePresence>

            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
              {filteredItems.map((_, index) => (
                <button
                  key={index}
                  onClick={(e) => {
                    e.stopPropagation();
                    setLightboxIndex(index);
                  }}
                  className={cn(
                    "w-2.5 h-2.5 rounded-full transition-all duration-300",
                    index === lightboxIndex
                      ? "bg-[#D4AF37] w-8"
                      : "bg-white/30 hover:bg-white/50"
                  )}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
