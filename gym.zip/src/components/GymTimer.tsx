"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, Pause, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";

const presets = [
  { label: "30s", seconds: 30 },
  { label: "1min", seconds: 60 },
  { label: "3min", seconds: 180 },
  { label: "5min", seconds: 300 },
];

const CIRCLE_RADIUS = 120;
const CIRCLE_CIRCUMFERENCE = 2 * Math.PI * CIRCLE_RADIUS;

export default function GymTimer() {
  const [duration, setDuration] = useState(60);
  const [timeRemaining, setTimeRemaining] = useState(60);
  const [isRunning, setIsRunning] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const progress = (timeRemaining / duration) * CIRCLE_CIRCUMFERENCE;
  const percentage = Math.round((timeRemaining / duration) * 100);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleStart = useCallback(() => {
    setIsRunning(true);
    setIsFinished(false);
  }, []);

  const handlePause = useCallback(() => {
    setIsRunning(false);
  }, []);

  const handleReset = useCallback(() => {
    setIsRunning(false);
    setTimeRemaining(duration);
    setIsFinished(false);
  }, [duration]);

  const handlePreset = useCallback((seconds: number) => {
    setIsRunning(false);
    setDuration(seconds);
    setTimeRemaining(seconds);
    setIsFinished(false);
  }, []);

  useEffect(() => {
    if (isRunning && timeRemaining > 0) {
      intervalRef.current = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            setIsRunning(false);
            setIsFinished(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, timeRemaining]);

  useEffect(() => {
    if (isFinished) {
      const timeout = setTimeout(() => {
        setIsFinished(false);
      }, 2000);
      return () => clearTimeout(timeout);
    }
  }, [isFinished]);

  return (
    <section id="timer" className="py-24 px-4 sm:px-6 lg:px-8 bg-[#0D0D0D]">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1 mb-4 text-xs font-semibold tracking-widest uppercase text-[#D4AF37] border border-[#D4AF37]/30 rounded-full">
            Workout Tool
          </span>
          <h2 className="text-4xl sm:text-5xl font-bold text-white tracking-tight">
            Gym Timer
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className={cn(
            "max-w-lg mx-auto rounded-3xl p-8 sm:p-12",
            "bg-white/5 backdrop-blur-md border border-white/10",
            "hover:border-[#D4AF37]/30 transition-all duration-500"
          )}
        >
          <div className="flex flex-col items-center gap-8">
            {/* Circular Timer */}
            <div className="relative">
              <motion.div
                animate={isFinished ? { scale: [1, 1.05, 1] } : {}}
                transition={{ duration: 0.5, repeat: isFinished ? Infinity : 0, repeatDelay: 0.3 }}
              >
                <svg
                  width="280"
                  height="280"
                  viewBox="0 0 280 280"
                  className="transform -rotate-90"
                >
                  {/* Background circle */}
                  <circle
                    cx="140"
                    cy="140"
                    r={CIRCLE_RADIUS}
                    fill="none"
                    stroke="rgba(255, 255, 255, 0.06)"
                    strokeWidth="8"
                  />
                  {/* Progress circle */}
                  <circle
                    cx="140"
                    cy="140"
                    r={CIRCLE_RADIUS}
                    fill="none"
                    stroke="url(#goldGradient)"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={CIRCLE_CIRCUMFERENCE}
                    strokeDashoffset={CIRCLE_CIRCUMFERENCE - progress}
                    style={{
                      transition: "stroke-dashoffset 0.3s ease-out",
                    }}
                  />
                  {/* Gradient definition */}
                  <defs>
                    <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#D4AF37" />
                      <stop offset="50%" stopColor="#E8C84A" />
                      <stop offset="100%" stopColor="#D4AF37" />
                    </linearGradient>
                  </defs>
                </svg>
              </motion.div>

              {/* Center content */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <motion.span
                  key={timeRemaining}
                  initial={{ scale: 0.98 }}
                  animate={{ scale: 1 }}
                  className={cn(
                    "text-5xl sm:text-6xl font-bold font-mono tracking-wider",
                    isFinished
                      ? "text-[#D4AF37]"
                      : timeRemaining <= 10 && isRunning
                      ? "text-red-500"
                      : "text-white"
                  )}
                >
                  {formatTime(timeRemaining)}
                </motion.span>
                <span className="text-sm text-white/40 mt-2 tracking-widest uppercase">
                  {percentage}%
                </span>
              </div>

              {/* Flash overlay on finish */}
              <AnimatePresence>
                {isFinished && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0, 0.3, 0] }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.8, repeat: Infinity }}
                    className="absolute inset-0 rounded-full border-2 border-[#D4AF37]/50"
                  />
                )}
              </AnimatePresence>
            </div>

            {/* Preset Buttons */}
            <div className="flex gap-3">
              {presets.map((preset) => (
                <motion.button
                  key={preset.seconds}
                  whileHover={{ scale: 1.08 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handlePreset(preset.seconds)}
                  className={cn(
                    "px-4 py-2 rounded-full text-sm font-semibold transition-all duration-300 cursor-pointer",
                    duration === preset.seconds
                      ? "bg-[#D4AF37] text-[#0D0D0D]"
                      : "bg-white/5 text-white/60 border border-white/10 hover:border-[#D4AF37]/50 hover:text-[#D4AF37]"
                  )}
                >
                  {preset.label}
                </motion.button>
              ))}
            </div>

            {/* Control Buttons */}
            <div className="flex gap-4">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={isRunning ? handlePause : handleStart}
                disabled={isFinished}
                className={cn(
                  "w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer",
                  "gold-gradient text-[#0D0D0D]",
                  isFinished && "opacity-50 cursor-not-allowed"
                )}
              >
                {isRunning ? (
                  <Pause className="w-7 h-7" />
                ) : (
                  <Play className="w-7 h-7 ml-1" />
                )}
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleReset}
                className={cn(
                  "w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer",
                  "bg-white/5 border border-white/10 text-white/70",
                  "hover:border-[#D4AF37]/50 hover:text-[#D4AF37]"
                )}
              >
                <RotateCcw className="w-6 h-6" />
              </motion.button>
            </div>

            {/* Status Text */}
            <p className="text-sm text-white/40 tracking-wide">
              {isFinished
                ? "Time's up! Great workout!"
                : isRunning
                ? "Keep pushing!"
                : "Ready to start"}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
