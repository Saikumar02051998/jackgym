"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const faqs = [
  {
    question: "What are the gym timings?",
    answer:
      "We are open Monday to Sunday, 5:00 AM to 10:00 PM. We are open all 7 days of the week including holidays.",
  },
  {
    question: "Do you offer personal training?",
    answer:
      "Yes, we offer certified personal trainers who create customized workout plans tailored to your goals. Our trainers specialize in strength training, weight loss, and bodybuilding.",
  },
  {
    question: "What diet plans do you provide?",
    answer:
      "We provide personalized diet plans based on your fitness goals. Our nutrition experts create balanced meal plans for weight loss, muscle gain, and overall wellness.",
  },
  {
    question: "Is there parking available?",
    answer:
      "Yes, we provide free parking space for both two-wheelers and four-wheelers for all our members.",
  },
  {
    question: "What is the membership cost?",
    answer:
      "We offer flexible membership plans starting from ₹999/month. Visit our pricing section or contact us for detailed pricing and current offers.",
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-24 px-4 sm:px-6 lg:px-8 bg-[#0D0D0D]">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1 mb-4 text-xs font-semibold tracking-widest uppercase text-[#D4AF37] border border-[#D4AF37]/30 rounded-full">
            FAQ
          </span>
          <h2 className="text-4xl sm:text-5xl font-bold text-white tracking-tight">
            FREQUENTLY ASKED QUESTIONS
          </h2>
        </motion.div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className={cn(
                "rounded-2xl backdrop-blur-md border transition-all duration-300",
                openIndex === index
                  ? "bg-white/5 border-[#D4AF37]/50 shadow-[0_0_30px_rgba(212,175,55,0.1)]"
                  : "bg-white/5 border-white/10 hover:border-white/20"
              )}
            >
              <button
                onClick={() => toggle(index)}
                className={cn(
                  "w-full flex items-center justify-between p-6 text-left",
                  "transition-colors duration-300"
                )}
              >
                <span
                  className={cn(
                    "text-lg font-medium transition-colors duration-300",
                    openIndex === index ? "text-[#D4AF37]" : "text-white"
                  )}
                >
                  {faq.question}
                </span>
                <motion.span
                  animate={{ rotate: openIndex === index ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="shrink-0 ml-4"
                >
                  <ChevronDown
                    className={cn(
                      "w-5 h-5 transition-colors duration-300",
                      openIndex === index ? "text-[#D4AF37]" : "text-gray-400"
                    )}
                  />
                </motion.span>
              </button>

              <AnimatePresence initial={false}>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-6">
                      <p className="text-gray-400 leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
