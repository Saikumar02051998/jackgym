"use client";

import { motion } from "framer-motion";
import {
  Dumbbell,
  Users,
  Heart,
  Flame,
  Activity,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";

const features = [
  {
    icon: Dumbbell,
    title: "Modern Equipment",
    description: "State-of-the-art machines and free weights for every workout.",
  },
  {
    icon: Users,
    title: "Expert Trainers",
    description: "Certified professionals guiding your fitness journey.",
  },
  {
    icon: Heart,
    title: "Strength & Conditioning",
    description: "Build power and endurance with proven programs.",
  },
  {
    icon: Flame,
    title: "Weight Loss Programs",
    description: "Personalized plans to shed fat and transform your body.",
  },
  {
    icon: Activity,
    title: "Cardio Zone",
    description: "Cutting-edge cardio equipment for peak performance.",
  },
  {
    icon: Zap,
    title: "Functional Training",
    description: "Dynamic movements for real-world strength and mobility.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" as const },
  },
};

export default function About() {
  return (
    <section
      id="about"
      className="relative w-full bg-[#0D0D0D] py-24 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-20">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="flex items-center justify-center"
          >
            <div
              className="relative h-[420px] w-full max-w-md overflow-hidden rounded-2xl"
              style={{
                background:
                  "linear-gradient(135deg, #0D0D0D 0%, #1a1a1a 40%, #2a1f0a 70%, #D4AF37 120%)",
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-transparent via-[#D4AF37]/10 to-[#D4AF37]/20" />
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                <Dumbbell className="h-20 w-20 text-[#D4AF37]/40" strokeWidth={1} />
                <span className="text-sm font-medium uppercase tracking-widest text-white/30">
                  Premium Fitness
                </span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="flex flex-col justify-center"
          >
            <span className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-[#D4AF37]">
              About Us
            </span>

            <h2 className="mb-6 text-4xl font-bold leading-tight text-white md:text-5xl">
              WHY CHOOSE <span className="text-[#D4AF37]">EMPIRE</span>?
            </h2>

            <p className="mb-12 max-w-lg text-base leading-relaxed text-white/70">
              The Empire Best Gym & Fitness Centre is Coimbatore&apos;s premier
              destination for transformation. We combine world-class equipment,
              expert trainers, and a relentless commitment to your goals — so
              every session brings you closer to the best version of yourself.
            </p>

            <motion.div
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              className="grid gap-4 sm:grid-cols-2 sm:gap-5"
            >
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={feature.title}
                    variants={cardVariants}
                    className={cn(
                      "group rounded-xl border border-white/[0.08] bg-white/[0.03] p-5",
                      "backdrop-blur-sm transition-colors duration-300 hover:border-[#D4AF37]/30 hover:bg-white/[0.06]"
                    )}
                  >
                    <Icon className="mb-3 h-6 w-6 text-[#D4AF37]" strokeWidth={1.5} />
                    <h3 className="mb-1 text-sm font-semibold text-white">
                      {feature.title}
                    </h3>
                    <p className="text-xs leading-relaxed text-white/50">
                      {feature.description}
                    </p>
                  </motion.div>
                );
              })}
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
