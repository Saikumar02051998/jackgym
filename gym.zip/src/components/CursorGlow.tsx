"use client";

import { useState, useEffect } from "react";

export default function CursorGlow() {
  const [position, setPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <div
      className="pointer-events-none fixed z-0"
      style={{
        width: "300px",
        height: "300px",
        borderRadius: "50%",
        background:
          "radial-gradient(circle, transparent 0%, rgba(212,175,55,0.06) 50%, rgba(212,175,55,0.02) 100%)",
        left: position.x - 150,
        top: position.y - 150,
        transition: "left 0.15s ease-out, top 0.15s ease-out",
        pointerEvents: "none",
      }}
    />
  );
}
