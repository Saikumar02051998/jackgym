"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Scale, TrendingUp, Info } from "lucide-react";
import { cn } from "@/lib/utils";

const getBMICategory = (bmi: number) => {
  if (bmi < 18.5) return { label: "Underweight", color: "#3B82F6", icon: "🔵" };
  if (bmi < 25) return { label: "Normal", color: "#22C55E", icon: "🟢" };
  if (bmi < 30) return { label: "Overweight", color: "#F97316", icon: "🟠" };
  return { label: "Obese", color: "#EF4444", icon: "🔴" };
};

const getRecommendation = (category: string) => {
  switch (category) {
    case "Underweight":
      return "Consider a nutrient-rich diet with increased calorie intake. Consult a nutritionist for a personalized plan.";
    case "Normal":
      return "You're in the healthy range. Maintain your current lifestyle with balanced nutrition and regular exercise.";
    case "Overweight":
      return "Incorporate regular cardio and strength training. Reduce processed foods and increase vegetable intake.";
    case "Obese":
      return "Consult a healthcare provider. Focus on gradual weight loss through sustainable lifestyle changes.";
    default:
      return "";
  }
};

export default function BMICalculator() {
  const [height, setHeight] = useState(170);
  const [weight, setWeight] = useState(70);
  const [bmiResult, setBmiResult] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const calculateBMI = () => {
    const heightInMeters = height / 100;
    const bmi = weight / (heightInMeters * heightInMeters);
    setBmiResult(Math.round(bmi * 10) / 10);
    setShowResult(true);
  };

  const category = bmiResult ? getBMICategory(bmiResult) : null;
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = bmiResult
    ? circumference - (Math.min(bmiResult, 40) / 40) * circumference
    : circumference;

  return (
    <section id="bmi" className="relative w-full bg-[#0D0D0D] py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block text-sm font-semibold uppercase tracking-[0.2em] text-[#D4AF37]">
            Health Check
          </span>
          <h2 className="text-4xl font-bold text-white md:text-5xl">
            BMI <span className="text-[#D4AF37]">CALCULATOR</span>
          </h2>
        </motion.div>

        <div className="mx-auto max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className={cn(
              "rounded-2xl border border-white/[0.08] p-8 backdrop-blur-xl",
              "bg-white/[0.03] shadow-2xl"
            )}
          >
            <div className="grid gap-8 md:grid-cols-2">
              <div className="space-y-6">
                <div>
                  <label className="mb-2 flex items-center justify-between text-sm font-medium text-white/70">
                    <span className="flex items-center gap-2">
                      <Scale className="h-4 w-4 text-[#D4AF37]" />
                      Height (cm)
                    </span>
                    <span className="font-semibold text-[#D4AF37]">{height}</span>
                  </label>
                  <input
                    type="range"
                    min="100"
                    max="220"
                    value={height}
                    onChange={(e) => setHeight(Number(e.target.value))}
                    className="h-2 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-[#D4AF37]"
                    style={{
                      background: `linear-gradient(to right, #D4AF37 0%, #D4AF37 ${((height - 100) / 120) * 100}%, rgba(255,255,255,0.1) ${((height - 100) / 120) * 100}%, rgba(255,255,255,0.1) 100%)`,
                    }}
                  />
                  <div className="mt-1 flex justify-between text-xs text-white/40">
                    <span>100 cm</span>
                    <span>220 cm</span>
                  </div>
                </div>

                <div>
                  <label className="mb-2 flex items-center justify-between text-sm font-medium text-white/70">
                    <span className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-[#D4AF37]" />
                      Weight (kg)
                    </span>
                    <span className="font-semibold text-[#D4AF37]">{weight}</span>
                  </label>
                  <input
                    type="range"
                    min="30"
                    max="200"
                    value={weight}
                    onChange={(e) => setWeight(Number(e.target.value))}
                    className="h-2 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-[#D4AF37]"
                    style={{
                      background: `linear-gradient(to right, #D4AF37 0%, #D4AF37 ${((weight - 30) / 170) * 100}%, rgba(255,255,255,0.1) ${((weight - 30) / 170) * 100}%, rgba(255,255,255,0.1) 100%)`,
                    }}
                  />
                  <div className="mt-1 flex justify-between text-xs text-white/40">
                    <span>30 kg</span>
                    <span>200 kg</span>
                  </div>
                </div>

                <button
                  onClick={calculateBMI}
                  className={cn(
                    "w-full rounded-xl py-4 font-semibold text-black transition-all duration-300",
                    "bg-gradient-to-r from-[#D4AF37] to-[#B8941F]",
                    "hover:from-[#E5C04A] hover:to-[#D4AF37]",
                    "hover:shadow-lg hover:shadow-[#D4AF37]/20"
                  )}
                >
                  Calculate BMI
                </button>
              </div>

              <div className="flex flex-col items-center justify-center">
                <AnimatePresence mode="wait">
                  {showResult && bmiResult !== null && category ? (
                    <motion.div
                      key="result"
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      transition={{ duration: 0.5, ease: "easeOut" }}
                      className="flex flex-col items-center"
                    >
                      <div className="relative mb-4">
                        <svg className="h-40 w-40 -rotate-90 transform" viewBox="0 0 100 100">
                          <circle
                            cx="50"
                            cy="50"
                            r="45"
                            fill="none"
                            stroke="rgba(255,255,255,0.05)"
                            strokeWidth="8"
                          />
                          <motion.circle
                            cx="50"
                            cy="50"
                            r="45"
                            fill="none"
                            stroke={category.color}
                            strokeWidth="8"
                            strokeLinecap="round"
                            strokeDasharray={circumference}
                            initial={{ strokeDashoffset: circumference }}
                            animate={{ strokeDashoffset }}
                            transition={{ duration: 1, ease: "easeOut" }}
                          />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <motion.span
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.3, duration: 0.5 }}
                            className="text-4xl font-bold text-white"
                          >
                            {bmiResult}
                          </motion.span>
                          <span className="text-xs text-white/50">BMI</span>
                        </div>
                      </div>

                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5, duration: 0.5 }}
                        className="text-center"
                      >
                        <span
                          className="mb-2 inline-block rounded-full px-4 py-1 text-sm font-semibold"
                          style={{ backgroundColor: `${category.color}20`, color: category.color }}
                        >
                          {category.label}
                        </span>
                      </motion.div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="placeholder"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex flex-col items-center text-center"
                    >
                      <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-white/[0.05]">
                        <Info className="h-8 w-8 text-white/20" />
                      </div>
                      <p className="text-sm text-white/40">
                        Adjust the sliders and click Calculate to see your BMI result
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            <AnimatePresence>
              {showResult && bmiResult !== null && category && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.5, delay: 0.7 }}
                  className="mt-8 overflow-hidden"
                >
                  <div className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-6">
                    <div className="mb-4 flex items-center justify-between">
                      <span className="text-sm font-medium text-white/50">Your Result</span>
                      <span className="text-3xl font-bold text-white">{bmiResult}</span>
                    </div>
                    <div className="mb-3 flex items-center justify-between">
                      <span className="text-sm font-medium text-white/50">Status</span>
                      <span className="font-semibold" style={{ color: category.color }}>
                        {category.label}
                      </span>
                    </div>
                    <div className="border-t border-white/[0.08] pt-4">
                      <p className="text-sm leading-relaxed text-white/60">
                        {getRecommendation(category.label)}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
