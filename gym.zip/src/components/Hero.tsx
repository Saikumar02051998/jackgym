"use client";

import { useState, useRef, type MouseEvent } from "react";
import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import {
  Star,
  Users,
  Clock,
  Award,
  ChevronDown,
  Dumbbell,
} from "lucide-react";
import { cn } from "@/lib/utils";

const stats = [
  { icon: Star, label: "Rating", value: "4.8", color: "text-[#D4AF37]" },
  { icon: Users, label: "Members", value: "1000+", color: "text-[#D4AF37]" },
  { icon: Clock, label: "Days Open", value: "7", color: "text-[#D4AF37]" },
  { icon: Award, label: "Certified Trainers", value: "Pro", color: "text-[#D4AF37]" },
] as const;

const headlineWords = ["UNLEASH", "YOUR", "STRONGEST SELF"];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.25 },
  },
};

const wordVariants = {
  hidden: { opacity: 0, y: 60, filter: "blur(8px)" },
  visible: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] as const },
  },
};

const subheadingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, delay: 1.0, ease: "easeOut" as const },
  },
};

const buttonVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: 1.3 + i * 0.15, ease: "easeOut" as const },
  }),
};

const statsVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.12, delayChildren: 1.6 },
  },
};

const statCardVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.9 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function Hero() {
  const [hoveredStat, setHoveredStat] = useState<number | null>(null);
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const heroRef = useRef<HTMLElement>(null);

  const backgroundX = useTransform(mouseX, [-1, 1], [-15, 15]);
  const backgroundY = useTransform(mouseY, [-1, 1], [-15, 15]);
  const contentX = useTransform(mouseX, [-1, 1], [10, -10]);
  const contentY = useTransform(mouseY, [-1, 1], [8, -8]);

  const handleMouseMove = (e: MouseEvent<HTMLElement>) => {
    const rect = heroRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = ((e.clientY - rect.top) / rect.height) * 2 - 1;
    animate(mouseX, x, { duration: 0.4, ease: "easeOut" });
    animate(mouseY, y, { duration: 0.4, ease: "easeOut" });
  };

  const scrollToContent = () => {
    window.scrollTo({ top: window.innerHeight, behavior: "smooth" });
  };

  return (
    <section
      ref={heroRef}
      onMouseMove={handleMouseMove}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background layers */}
      <motion.div
        style={{ x: backgroundX, y: backgroundY }}
        className="absolute inset-0 z-0"
      >
        {/* Base dark gradient with subtle gold accents */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0D0D0D] via-[#111111] to-[#0D0D0D]" />
        {/* Gold accent radial glow */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(212,175,55,0.08)_0%,transparent_60%)]" />
        {/* Dark overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-[#0D0D0D]" />
        {/* Corner accent glow */}
        <div className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.06)_0%,transparent_70%)]" />
        <div className="absolute -bottom-40 -left-40 w-[500px] h-[500px] rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.04)_0%,transparent_70%)]" />
      </motion.div>

      {/* Floating dumbbell decorative elements */}
      <motion.div
        style={{ x: backgroundX, y: backgroundY }}
        className="absolute inset-0 z-0 pointer-events-none"
      >
        <motion.div
          animate={{ y: [-20, 20, -20], rotate: [-15, 15, -15] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[15%] left-[8%] opacity-[0.04]"
        >
          <Dumbbell className="w-24 h-24 text-[#D4AF37]" />
        </motion.div>
        <motion.div
          animate={{ y: [15, -15, 15], rotate: [20, -20, 20] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[25%] right-[10%] opacity-[0.03]"
        >
          <Dumbbell className="w-16 h-16 text-[#D4AF37]" />
        </motion.div>
        <motion.div
          animate={{ y: [-10, 10, -10], rotate: [-25, 25, -25] }}
          transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-[20%] left-[15%] opacity-[0.03]"
        >
          <Dumbbell className="w-20 h-20 text-[#D4AF37]" />
        </motion.div>
        <motion.div
          animate={{ y: [10, -10, 10], rotate: [10, -10, 10] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-[30%] right-[5%] opacity-[0.025]"
        >
          <Dumbbell className="w-14 h-14 text-[#D4AF37]" />
        </motion.div>
      </motion.div>

      {/* Content */}
      <motion.div
        style={{ x: contentX, y: contentY }}
        className="relative z-10 text-center px-6 max-w-5xl mx-auto"
      >
        {/* Headline */}
        <motion.h1
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="font-heading font-black tracking-tight leading-[0.9] mb-8"
        >
          {headlineWords.map((word, i) => (
            <motion.span
              key={i}
              variants={wordVariants}
              className={cn(
                "block",
                i === 2
                  ? "text-5xl sm:text-7xl md:text-8xl lg:text-9xl text-gold-gradient"
                  : "text-5xl sm:text-7xl md:text-8xl lg:text-9xl text-white"
              )}
            >
              {word}
            </motion.span>
          ))}
        </motion.h1>

        {/* Subheadings */}
        <motion.div variants={subheadingVariants} initial="hidden" animate="visible">
          <p className="text-lg sm:text-xl md:text-2xl font-light text-white/80 mb-2 tracking-wide">
            The Empire Best Gym & Fitness Centre
          </p>
          <p className="text-sm sm:text-base md:text-lg text-[#D4AF37]/70 font-medium tracking-widest uppercase">
            Coimbatore&apos;s Premium Fitness Destination
          </p>
        </motion.div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10">
          <motion.button
            custom={0}
            variants={buttonVariants}
            initial="hidden"
            animate="visible"
            whileHover={{ scale: 1.05, boxShadow: "0 0 40px rgba(212,175,55,0.4)" }}
            whileTap={{ scale: 0.97 }}
            className={cn(
              "px-8 py-4 rounded-lg font-semibold text-lg text-black",
              "gold-gradient animate-gradient",
              "transition-all duration-300 cursor-pointer"
            )}
          >
            Join Today
          </motion.button>
          <motion.button
            custom={1}
            variants={buttonVariants}
            initial="hidden"
            animate="visible"
            whileHover={{ scale: 1.05, backgroundColor: "rgba(212,175,55,0.1)" }}
            whileTap={{ scale: 0.97 }}
            className={cn(
              "px-8 py-4 rounded-lg font-semibold text-lg",
              "border border-[#D4AF37]/40 text-[#D4AF37]",
              "hover-glow transition-all duration-300 cursor-pointer",
              "bg-transparent"
            )}
          >
            Book Free Trial
          </motion.button>
        </div>

        {/* Floating stats */}
        <motion.div
          variants={statsVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 max-w-3xl mx-auto"
        >
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={i}
                variants={statCardVariants}
                onMouseEnter={() => setHoveredStat(i)}
                onMouseLeave={() => setHoveredStat(null)}
                animate={{
                  y: hoveredStat === i ? -8 : [0, -6, 0],
                  boxShadow:
                    hoveredStat === i
                      ? "0 8px 32px rgba(212,175,55,0.2)"
                      : "0 4px 16px rgba(0,0,0,0.3)",
                }}
                transition={
                  hoveredStat === i
                    ? { duration: 0.3 }
                    : {
                        y: {
                          duration: 4 + i * 0.5,
                          repeat: Infinity,
                          ease: "easeInOut",
                        },
                      }
                }
                className={cn(
                  "glass rounded-xl p-4 sm:p-5 flex flex-col items-center gap-2",
                  "neon-border transition-all duration-300",
                  "cursor-default"
                )}
              >
                <Icon className={cn("w-6 h-6 sm:w-7 sm:h-7", stat.color)} />
                <span className="text-xl sm:text-2xl font-bold text-white">
                  {stat.value}
                </span>
                <span className="text-xs sm:text-sm text-white/50 font-medium tracking-wide">
                  {stat.label}
                </span>
              </motion.div>
            );
          })}
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.button
        onClick={scrollToContent}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.2, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 cursor-pointer bg-transparent border-none"
      >
        <span className="text-xs text-white/40 tracking-widest uppercase font-medium">
          Scroll
        </span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        >
          <ChevronDown className="w-6 h-6 text-[#D4AF37]/60" />
        </motion.div>
      </motion.button>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0D0D0D] to-transparent z-10 pointer-events-none" />
    </section>
  );
}
