"use client";

import { motion } from "framer-motion";
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Dumbbell,
} from "lucide-react";

function InstagramIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}

function FacebookIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
    </svg>
  );
}

function TwitterIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
    </svg>
  );
}
import { cn } from "@/lib/utils";

const quickLinks = [
  { label: "Home", href: "#home" },
  { label: "Programs", href: "#programs" },
  { label: "Trainers", href: "#trainers" },
  { label: "Pricing", href: "#pricing" },
  { label: "Gallery", href: "#gallery" },
  { label: "Testimonials", href: "#testimonials" },
];

const programs = [
  "Strength Training",
  "Fat Loss",
  "Bodybuilding",
  "Personal Training",
  "HIIT",
  "Cardio",
];

const contactInfo = [
  {
    icon: MapPin,
    text: "123 Fitness Avenue, RS Puram, Coimbatore, Tamil Nadu 641002",
  },
  {
    icon: Phone,
    text: "+91 98765 43210",
  },
  {
    icon: Mail,
    text: "info@theempiregym.com",
  },
  {
    icon: Clock,
    text: "Mon - Sat: 5:00 AM - 10:00 PM",
  },
];

const socials = [
  { icon: InstagramIcon, href: "#", label: "Instagram" },
  { icon: FacebookIcon, href: "#", label: "Facebook" },
  { icon: TwitterIcon, href: "#", label: "Twitter" },
];

const handleScroll = (href: string) => {
  const el = document.querySelector(href);
  if (el) {
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
};

export default function Footer() {
  return (
    <footer className="relative border-t border-[#D4AF37]/20 bg-[#0D0D0D]">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Logo Column */}
          <div className="flex flex-col gap-6">
            <button onClick={() => handleScroll("#home")} className="group flex items-center gap-3 self-start">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg gold-gradient">
                <Dumbbell className="h-5 w-5 text-[#0D0D0D]" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-heading text-lg font-bold tracking-[0.15em] text-gold-gradient">
                  THE EMPIRE
                </span>
                <span className="text-[10px] font-medium uppercase tracking-[0.2em] text-white/50">
                  Best Gym & Fitness Centre
                </span>
              </div>
            </button>
            <p className="text-sm leading-relaxed text-white/50">
              Transform your body, elevate your mind. Premium fitness experience
              with world-class equipment and certified trainers in the heart of
              Coimbatore.
            </p>
            <div className="flex items-center gap-4">
              {socials.map((social) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-white/50 transition-colors hover:border-[#D4AF37]/50 hover:text-[#D4AF37]"
                  aria-label={social.label}
                >
                  <social.icon className="h-4 w-4" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className="flex flex-col gap-6">
            <h3 className="font-heading text-sm font-semibold uppercase tracking-[0.2em] text-white">
              Quick Links
            </h3>
            <ul className="flex flex-col gap-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <motion.button
                    onClick={() => handleScroll(link.href)}
                    whileHover={{ x: 4 }}
                    className="text-sm text-white/50 transition-colors hover:text-[#D4AF37]"
                  >
                    {link.label}
                  </motion.button>
                </li>
              ))}
            </ul>
          </div>

          {/* Programs */}
          <div className="flex flex-col gap-6">
            <h3 className="font-heading text-sm font-semibold uppercase tracking-[0.2em] text-white">
              Programs
            </h3>
            <ul className="flex flex-col gap-3">
              {programs.map((program) => (
                <li key={program}>
                  <span className="text-sm text-white/50 transition-colors hover:text-[#D4AF37]">
                    {program}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="flex flex-col gap-6">
            <h3 className="font-heading text-sm font-semibold uppercase tracking-[0.2em] text-white">
              Contact
            </h3>
            <ul className="flex flex-col gap-4">
              {contactInfo.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <item.icon className="mt-0.5 h-4 w-4 shrink-0 text-[#D4AF37]" />
                  <span className="text-sm leading-relaxed text-white/50">
                    {item.text}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-6 sm:flex-row lg:px-8">
          <p className="text-center text-xs text-white/40 sm:text-left">
            &copy; 2026 The Empire Best Gym & Fitness Centre. All rights reserved.
          </p>
          <p className="text-center text-xs text-white/40 sm:text-right">
            Made with ❤ in Coimbatore
          </p>
        </div>
      </div>
    </footer>
  );
}
