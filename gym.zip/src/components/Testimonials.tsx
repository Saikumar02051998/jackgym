"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { cn } from "@/lib/utils";

const testimonials = [
  {
    quote: "The Empire transformed my life. Lost 20kg in 6 months!",
    name: "Vikram S.",
    achievement: "Lost 20kg",
    initials: "VS",
  },
  {
    quote: "Best trainers in Coimbatore. The equipment is world-class.",
    name: "Sneha R.",
    achievement: "Member for 2 years",
    initials: "SR",
  },
  {
    quote: "Personal training program is worth every penny. Amazing results!",
    name: "Karthik M.",
    achievement: "Gained muscle",
    initials: "KM",
  },
  {
    quote: "The atmosphere and motivation here is unmatched. Love it!",
    name: "Priya K.",
    achievement: "Fitness enthusiast",
    initials: "PK",
  },
  {
    quote: "From couch to marathon runner. Empire made it possible!",
    name: "Arjun T.",
    achievement: "Ran marathon",
    initials: "AT",
  },
];

export default function Testimonials() {
  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(0);

  const next = useCallback(() => {
    setDirection(1);
    setCurrent((prev) => (prev + 1) % testimonials.length);
  }, []);

  const prev = useCallback(() => {
    setDirection(-1);
    setCurrent(
      (prev) => (prev - 1 + testimonials.length) % testimonials.length
    );
  }, []);

  useEffect(() => {
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, [next]);

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0,
    }),
    center: { x: 0, opacity: 1 },
    exit: (direction: number) => ({
      x: direction < 0 ? 300 : -300,
      opacity: 0,
    }),
  };

  return (
    <section
      id="testimonials"
      className="relative py-24 px-4 md:px-8"
      style={{ backgroundColor: "#0D0D0D" }}
    >
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span
            className="inline-block px-4 py-1 rounded-full text-sm font-semibold tracking-wider mb-4"
            style={{
              background: "linear-gradient(135deg, #D4AF37, #B8962E)",
              color: "#0D0D0D",
            }}
          >
            TESTIMONIALS
          </span>
          <h2
            className="text-4xl md:text-5xl font-bold"
            style={{ color: "#FFFFFF" }}
          >
            WHAT OUR MEMBERS SAY
          </h2>
        </motion.div>

        <div className="relative max-w-3xl mx-auto">
          <div className="overflow-hidden relative h-[340px]">
            <AnimatePresence custom={direction} mode="wait">
              <motion.div
                key={current}
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.4, ease: "easeInOut" }}
                className={cn(
                  "absolute inset-0 rounded-2xl p-8 md:p-10",
                  "backdrop-blur-xl border border-white/10",
                  "shadow-2xl"
                )}
                style={{
                  background:
                    "linear-gradient(135deg, rgba(212,175,55,0.1), rgba(13,13,13,0.8))",
                }}
              >
                <Quote
                  className="w-10 h-10 mb-6 opacity-40"
                  style={{ color: "#D4AF37" }}
                />
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-5 h-5 fill-current"
                      style={{ color: "#D4AF37" }}
                    />
                  ))}
                </div>
                <p
                  className="text-xl md:text-2xl font-medium leading-relaxed mb-8"
                  style={{ color: "#FFFFFF" }}
                >
                  &ldquo;{testimonials[current].quote}&rdquo;
                </p>
                <div className="flex items-center gap-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold"
                    style={{
                      background:
                        "linear-gradient(135deg, #D4AF37, #B8962E)",
                      color: "#0D0D0D",
                    }}
                  >
                    {testimonials[current].initials}
                  </div>
                  <div>
                    <p
                      className="font-semibold text-lg"
                      style={{ color: "#FFFFFF" }}
                    >
                      {testimonials[current].name}
                    </p>
                    <p
                      className="text-sm"
                      style={{ color: "#D4AF37" }}
                    >
                      {testimonials[current].achievement}
                    </p>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          <button
            onClick={prev}
            className={cn(
              "absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2",
              "w-12 h-12 rounded-full flex items-center justify-center",
              "border border-white/20 backdrop-blur-md",
              "hover:border-[#D4AF37] transition-colors duration-300",
              "hidden md:flex"
            )}
            style={{
              background: "rgba(13,13,13,0.6)",
            }}
          >
            <ChevronLeft className="w-5 h-5" style={{ color: "#FFFFFF" }} />
          </button>
          <button
            onClick={next}
            className={cn(
              "absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2",
              "w-12 h-12 rounded-full flex items-center justify-center",
              "border border-white/20 backdrop-blur-md",
              "hover:border-[#D4AF37] transition-colors duration-300",
              "hidden md:flex"
            )}
            style={{
              background: "rgba(13,13,13,0.6)",
            }}
          >
            <ChevronRight className="w-5 h-5" style={{ color: "#FFFFFF" }} />
          </button>

          <div className="flex justify-center gap-3 mt-8">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => {
                  setDirection(i > current ? 1 : -1);
                  setCurrent(i);
                }}
                className={cn(
                  "w-3 h-3 rounded-full transition-all duration-300",
                  i === current ? "w-8" : "hover:opacity-80"
                )}
                style={{
                  background:
                    i === current ? "#D4AF37" : "rgba(255,255,255,0.3)",
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
