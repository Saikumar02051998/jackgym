"use client";

import { useState, useRef, useCallback, useEffect } from "react";
import { motion, useInView, animate } from "framer-motion";
import { ArrowRight, TrendingUp, Flame, Heart, Dumbbell } from "lucide-react";
import { cn } from "@/lib/utils";

const metrics = [
  {
    label: "Strength",
    before: 40,
    after: 95,
    icon: Dumbbell,
    color: "from-[#D4AF37] to-[#B8941F]",
  },
  {
    label: "Endurance",
    before: 30,
    after: 85,
    icon: Heart,
    color: "from-[#D4AF37] to-[#E8C84A]",
  },
  {
    label: "Body Fat",
    before: 35,
    after: 18,
    icon: Flame,
    color: "from-[#D4AF37] to-[#C9A227]",
  },
  {
    label: "Muscle Mass",
    before: 45,
    after: 80,
    icon: TrendingUp,
    color: "from-[#D4AF37] to-[#D4AF37]",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" as const },
  },
};

function AnimatedProgress({
  label,
  before,
  after,
  icon: Icon,
  color,
  inView,
}: {
  label: string;
  before: number;
  after: number;
  icon: React.ElementType;
  color: string;
  inView: boolean;
}) {
  const [beforeWidth, setBeforeWidth] = useState(0);
  const [afterWidth, setAfterWidth] = useState(0);

  useEffect(() => {
    if (inView) {
      const beforeAnim = animate(0, before, {
        duration: 1.5,
        ease: "easeOut",
        onUpdate: (v) => setBeforeWidth(v),
      });
      const afterAnim = animate(0, after, {
        duration: 1.8,
        ease: "easeOut",
        onUpdate: (v) => setAfterWidth(v),
      });
      return () => {
        beforeAnim.stop();
        afterAnim.stop();
      };
    }
  }, [inView, before, after]);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#D4AF37]/10 flex items-center justify-center">
            <Icon className="w-5 h-5 text-[#D4AF37]" />
          </div>
          <span className="text-white font-medium">{label}</span>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <span className="text-gray-500">{Math.round(beforeWidth)}%</span>
          <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
          <span className="text-[#D4AF37] font-bold">{Math.round(afterWidth)}%</span>
        </div>
      </div>

      <div className="relative h-3 bg-white/5 rounded-full overflow-hidden backdrop-blur-sm border border-white/10">
        <motion.div
          className={cn("absolute inset-y-0 left-0 rounded-full bg-gradient-to-r opacity-30", color)}
          style={{ width: `${beforeWidth}%` }}
        />
        <motion.div
          className={cn("absolute inset-y-0 left-0 rounded-full bg-gradient-to-r", color)}
          style={{ width: `${afterWidth}%` }}
        />
      </div>
    </div>
  );
}

export default function Transformation() {
  const sectionRef = useRef<HTMLElement>(null);
  const metricsRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" });
  const metricsInView = useInView(metricsRef, { once: true, margin: "-50px" });

  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);

  const handleSliderMove = useCallback(
    (clientX: number) => {
      if (!sliderRef.current || !isDragging) return;
      const rect = sliderRef.current.getBoundingClientRect();
      const x = clientX - rect.left;
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      setSliderPosition(percentage);
    },
    [isDragging]
  );

  const handleMouseDown = useCallback(() => {
    setIsDragging(true);
  }, []);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      handleSliderMove(e.clientX);
    },
    [handleSliderMove]
  );

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      handleSliderMove(e.touches[0].clientX);
    },
    [handleSliderMove]
  );

  useEffect(() => {
    const handleGlobalMouseUp = () => setIsDragging(false);
    const handleGlobalMouseMove = (e: MouseEvent) => {
      if (isDragging) handleSliderMove(e.clientX);
    };

    window.addEventListener("mouseup", handleGlobalMouseUp);
    window.addEventListener("mousemove", handleGlobalMouseMove);

    return () => {
      window.removeEventListener("mouseup", handleGlobalMouseUp);
      window.removeEventListener("mousemove", handleGlobalMouseMove);
    };
  }, [isDragging, handleSliderMove]);

  return (
    <section
      id="transformation"
      ref={sectionRef}
      className="py-24 px-4 sm:px-6 lg:px-8 bg-[#0D0D0D]"
    >
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1 mb-4 text-xs font-semibold tracking-widest uppercase text-[#D4AF37] border border-[#D4AF37]/30 rounded-full">
            Transformations
          </span>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight">
            <span className="text-white">Real Results.</span>
            <br />
            <span className="text-gold-gradient">Real Transformation.</span>
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <div
              ref={sliderRef}
              className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden cursor-ew-resize select-none bg-white/5 backdrop-blur-md border border-white/10"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onTouchStart={handleMouseDown}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleMouseUp}
            >
              <div
                className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] via-[#0f0f0f] to-[#151515]"
                style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
              >
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-white/10 border border-white/20" />
                    <p className="text-white/60 text-sm tracking-widest uppercase">
                      Before
                    </p>
                  </div>
                </div>
              </div>

              <div
                className="absolute inset-0 bg-gradient-to-br from-[#2a2010] via-[#1a1505] to-[#252010]"
                style={{ clipPath: `inset(0 0 0 ${sliderPosition}%)` }}
              >
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 shadow-[0_0_30px_rgba(212,175,55,0.3)]" />
                    <p className="text-[#D4AF37] text-sm tracking-widest uppercase font-semibold">
                      After
                    </p>
                  </div>
                </div>
              </div>

              <div
                className="absolute inset-y-0 w-1 bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]"
                style={{ left: `${sliderPosition}%`, transform: "translateX(-50%)" }}
              >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/90 backdrop-blur-md border-2 border-white flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.4)] cursor-grab active:cursor-grabbing">
                  <div className="flex gap-1">
                    <div className="w-0.5 h-4 bg-gray-400 rounded-full" />
                    <div className="w-0.5 h-4 bg-gray-400 rounded-full" />
                  </div>
                </div>
              </div>

              <div className="absolute top-4 left-4 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-sm border border-white/20">
                <span className="text-white text-xs font-semibold tracking-wider">
                  BEFORE
                </span>
              </div>
              <div className="absolute top-4 right-4 px-3 py-1.5 rounded-full bg-[#D4AF37]/20 backdrop-blur-sm border border-[#D4AF37]/40">
                <span className="text-[#D4AF37] text-xs font-semibold tracking-wider">
                  AFTER
                </span>
              </div>
            </div>
          </motion.div>

          <motion.div
            ref={metricsRef}
            variants={containerVariants}
            initial="hidden"
            animate={isInView ? "visible" : "hidden"}
            className="space-y-6"
          >
            <motion.div variants={itemVariants} className="mb-8">
              <h3 className="text-2xl font-bold text-white mb-2">
                Measurable Progress
              </h3>
              <p className="text-gray-400">
                Every transformation is tracked with precision. See real numbers, real results.
              </p>
            </motion.div>

            {metrics.map((metric) => (
              <motion.div key={metric.label} variants={itemVariants}>
                <AnimatedProgress
                  {...metric}
                  inView={metricsInView}
                />
              </motion.div>
            ))}

            <motion.div
              variants={itemVariants}
              className="mt-8 p-6 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-[#D4AF37]" />
                </div>
                <div>
                  <p className="text-white font-semibold">Average 12-Week Result</p>
                  <p className="text-gray-400 text-sm">
                    Our members see significant improvements in just 3 months
                  </p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
